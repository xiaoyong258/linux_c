#ifndef __RMVB_H
#define __RMVB_H
void rmvb_init();
#endif
