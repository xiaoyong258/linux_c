#ifndef __USB_H
#define __USB_H
void usb_init();
#define VERSION "3.0"
#endif
