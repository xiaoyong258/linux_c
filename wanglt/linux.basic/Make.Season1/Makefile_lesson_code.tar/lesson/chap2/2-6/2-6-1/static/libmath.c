#include <stdio.h>

void libmath_init()
{
	printf("libmath_init ...\n");

}
