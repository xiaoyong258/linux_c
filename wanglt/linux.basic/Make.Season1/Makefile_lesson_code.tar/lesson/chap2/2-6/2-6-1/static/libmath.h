#ifndef __LIBMATH_H
#define __LIBMATH_H
void libmath_init();
#endif

