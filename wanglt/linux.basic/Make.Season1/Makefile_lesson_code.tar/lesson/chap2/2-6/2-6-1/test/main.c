#include<stdio.h>
#include"libmath.h"
int main()
{
	printf("hello world!\n");
	libmath_init();
	return 0;
}
