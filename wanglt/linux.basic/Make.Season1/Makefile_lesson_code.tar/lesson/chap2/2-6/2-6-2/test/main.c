#include<stdio.h>
#include "dll.h"
int main()
{
	printf("hello world!\n");
	dll_init();
	return 0;
}
