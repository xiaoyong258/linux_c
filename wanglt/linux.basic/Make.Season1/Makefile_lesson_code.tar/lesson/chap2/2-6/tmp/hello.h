#ifndef __HELLO_H
#define __HELLO_H
void hello();
#endif
