#include<stdio.h>
#include "hello.h"
int main()

{
	printf("hello main!\n");
	hello();
	return 0;
}
