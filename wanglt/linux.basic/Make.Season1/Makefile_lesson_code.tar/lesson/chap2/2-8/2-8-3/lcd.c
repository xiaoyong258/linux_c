#include<stdio.h>

void lcd_init()
{
	printf("lcd init...\n");

}
