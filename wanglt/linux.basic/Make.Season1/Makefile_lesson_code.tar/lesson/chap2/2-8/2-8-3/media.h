void media_init();
