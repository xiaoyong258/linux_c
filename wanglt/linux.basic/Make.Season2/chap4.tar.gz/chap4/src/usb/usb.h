#ifndef __USB_H
#define __USB_H
void usb_init();
#endif
