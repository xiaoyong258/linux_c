/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Name of package */
#define PACKAGE "mp3"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "ddblog@qq.com"

/* Define to the full name of this package. */
#define PACKAGE_NAME "mp3"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "mp3 4.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "mp3"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "4.0"

/* Version number of package */
#define VERSION "4.0"
