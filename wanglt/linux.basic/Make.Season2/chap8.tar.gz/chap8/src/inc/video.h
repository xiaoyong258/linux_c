#ifndef __VIDEO_H
#define __VIDEO_H
void video_init();
#endif
