#include<stdio.h>
#include "usb.h"
void usb_init()
{
	printf("usb init...\n");
}
