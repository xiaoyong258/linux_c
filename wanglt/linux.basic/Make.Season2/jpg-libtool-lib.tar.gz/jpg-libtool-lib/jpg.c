#include<stdio.h>

void jpg_init()
{
	printf("jpg init...\n");
}
