#include<stdio.h>
void h264_init()
{
	printf("h264 init...\n");
}
