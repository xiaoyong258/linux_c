#ifndef __LCD_H
#define __LCD_H
void lcd_init();

#endif
