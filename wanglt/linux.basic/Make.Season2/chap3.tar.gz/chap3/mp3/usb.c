#include<stdio.h>

void usb_init()
{
	printf("usb init...\n");
}
