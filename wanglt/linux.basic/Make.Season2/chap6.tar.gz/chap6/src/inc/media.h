#ifndef __MEDIA__H
#define __MEDIA__H
void media_init();
#endif
