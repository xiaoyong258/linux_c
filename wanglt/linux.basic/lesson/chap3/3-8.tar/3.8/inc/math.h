#ifndef __MATH_H
#define __MATH_H
void math_dll_init();
#endif
