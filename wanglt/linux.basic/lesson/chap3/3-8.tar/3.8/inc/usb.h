#ifndef __USB_H
#define __USB_H
#include "usb20.h"
void usb_init();
#endif
