#include <stdio.h>

void math_dll_init()
{
	printf("math dll init...\n");
}
