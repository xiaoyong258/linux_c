#ifndef __JPG_H
#define __JPG_H
void jpg_init();
#endif
