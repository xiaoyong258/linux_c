#ifndef __USB20_H
#define __USB20_H
#define VERSION "3.0"
#endif
