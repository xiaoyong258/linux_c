#include<stdio.h>

void media_init()
{
	printf("media init...\n");
}
